import { useEffect, useMemo, useState } from "react";

const API = "http://localhost:3001/api";

const SUBJECTS = [
  { id: "math", name: "Core Mathematics", short: "MAT", icon: "∑", color: "violet", summary: "Build confidence with numbers, patterns and problem-solving.", topics: ["Number sets", "Surds", "Sequences and series", "Algebra", "Geometry"] },
  { id: "english", name: "English Language", short: "ENG", icon: "Aa", color: "orange", summary: "Strengthen grammar, comprehension and communication.", topics: ["Formal letter writing", "Comprehension", "Summary writing", "Speech writing", "Grammar"] },
  { id: "social", name: "Social Studies", short: "SOC", icon: "◎", color: "green", summary: "Explore citizenship, society, sustainability and development.", topics: ["Citizenship", "The environment", "Governance", "Culture and identity", "Essay practice"] },
  { id: "computing", name: "Computing", short: "ICT", icon: "</>", color: "blue", summary: "Discover computer systems, coding and digital problem-solving.", topics: ["Computer systems", "HTML and CSS", "Databases", "Cyber safety", "Algorithms"] },
  { id: "science", name: "Integrated Science", short: "SCI", icon: "✳", color: "teal", summary: "Understand living things, matter, energy and the environment.", topics: ["Cells and life", "Matter", "Energy", "Ecosystems", "Scientific methods"] },
  { id: "art", name: "Visual Arts", short: "ART", icon: "✎", color: "pink", summary: "Explore visual expression, design principles and creative practice.", topics: ["Elements of art", "Design principles", "Colour theory", "Drawing", "Art appreciation"] }
];

const QUIZ = [
  { question: "Which number is a prime number?", options: ["9", "11", "15", "21"], answer: 1, explain: "11 has exactly two positive factors: 1 and 11." },
  { question: "Which sentence is written in the formal style?", options: ["Hey, what's up?", "Send me that thing.", "I am writing to request further information.", "See you later!"], answer: 2, explain: "Formal writing uses respectful, clear language appropriate to official communication." },
  { question: "Which is an example of a database?", options: ["A collection of organised student records", "A computer monitor", "A power cable", "A keyboard key"], answer: 0, explain: "A database stores organised information that can be searched and managed." }
];

const TOPIC_DETAILS = {
  "Number sets": { intro: "Number sets group numbers according to shared properties.", points: ["Natural numbers count objects: 1, 2, 3, …", "Integers include negative whole numbers, zero and positive whole numbers.", "Rational numbers can be expressed as a fraction of integers with a non-zero denominator."], example: "−3 is an integer and a rational number because −3 = −3/1." },
  "Surds": { intro: "A surd is an irrational root that cannot be simplified to a rational number.", points: ["Simplify by taking out perfect-square factors.", "Only like surds can be added directly.", "Use conjugates when rationalising some denominators."], example: "√12 = √(4 × 3) = 2√3." },
  "Sequences and series": { intro: "A sequence is an ordered list of terms. A series is the sum of terms.", points: ["An arithmetic sequence has a constant difference.", "A geometric sequence has a constant ratio.", "Look for a rule before finding an unknown term."], example: "For 3, 6, 9, 12, … the common difference is 3." },
  "Formal letter writing": { intro: "A formal letter communicates respectfully in an official or professional situation.", points: ["Include the sender's address and date where required.", "Use a suitable recipient address and salutation.", "Organise the message into clear paragraphs and use an appropriate closing."], example: "Opening: I am writing to enquire about the requirements for…" },
  "Comprehension": { intro: "Comprehension involves reading a passage carefully and answering from evidence in the text.", points: ["Read the question before selecting evidence.", "Use context to infer unfamiliar words.", "Answer in your own words when the question requires it."], example: "For a question asking why, identify the cause stated or implied by the passage." },
  "Computer systems": { intro: "A computer system combines hardware, software, data and people to process information.", points: ["Hardware is the physical equipment.", "Software contains programs and instructions.", "Input, processing, output and storage work together."], example: "A keyboard is an input device; a monitor is an output device." },
  "HTML and CSS": { intro: "HTML structures a web page, while CSS controls its presentation and layout.", points: ["Use semantic HTML elements to describe page structure.", "Use CSS for colour, spacing, typography and responsive layouts.", "JavaScript can add behaviour and interactivity."], example: "An <h1> element marks a main heading; CSS can style it." },
  "Introduction to databases": { intro: "A database stores information in a structured way so it can be retrieved and updated.", points: ["Tables contain rows and columns.", "A primary key uniquely identifies a row.", "SQL can be used to query and update relational databases."], example: "A students table might contain id, name and class columns." }
};

function getLesson(topic, subject) {
  return TOPIC_DETAILS[topic] || {
    intro: `${topic} is one of the topics you can explore in ${subject}. Start by learning the key terms, then work through examples and practice questions.`,
    points: ["Write down the main concepts and definitions.", "Study a worked example and explain each step.", "Try a practice question and check your reasoning."],
    example: `Create a short summary of ${topic} in your own words.`
  };
}

export default function App() {
  const [page, setPage] = useState("Home");
  const [year, setYear] = useState("SHS 1");
  const [search, setSearch] = useState("");
  const [subjectId, setSubjectId] = useState("math");
  const [topic, setTopic] = useState(null);
  const [saved, setSaved] = useState([]);
  const [completed, setCompleted] = useState([]);
  const [quizOpen, setQuizOpen] = useState(false);
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizChoice, setQuizChoice] = useState(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState(null);
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [toast, setToast] = useState("");
  const [apiStatus, setApiStatus] = useState("checking");

  const activeSubject = SUBJECTS.find(s => s.id === subjectId) || SUBJECTS[0];
  const visibleSubjects = useMemo(() => SUBJECTS.filter(s => s.name.toLowerCase().includes(search.toLowerCase())), [search]);
  const lesson = topic ? getLesson(topic, activeSubject.name) : null;

  useEffect(() => {
    try {
      setSaved(JSON.parse(localStorage.getItem("upford-saved") || "[]"));
      setCompleted(JSON.parse(localStorage.getItem("upford-completed") || "[]"));
    } catch { localStorage.removeItem("upford-saved"); localStorage.removeItem("upford-completed"); }
    fetch(`${API}/health`, { credentials: "include" })
      .then(r => { if (!r.ok) throw new Error(); setApiStatus("online"); })
      .catch(() => setApiStatus("offline"));
    fetch(`${API}/auth/me`, { credentials: "include" })
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data?.user) setUser(data.user); })
      .catch(() => {});
  }, []);

  function notify(message) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }
  function toggleSaved(title) {
    const next = saved.includes(title) ? saved.filter(t => t !== title) : [...saved, title];
    setSaved(next);
    localStorage.setItem("upford-saved", JSON.stringify(next));
    notify(next.includes(title) ? "Lesson saved to My Learning." : "Lesson removed from My Learning.");
  }
  function markCompleted(title) {
    const next = completed.includes(title) ? completed : [...completed, title];
    setCompleted(next);
    localStorage.setItem("upford-completed", JSON.stringify(next));
    notify("Nice work — lesson marked complete!");
  }
  async function submitAuth(e) {
    e.preventDefault();
    setAuthBusy(true);
    setAuthError("");
    try {
      const endpoint = authMode === "register" ? "register" : "login";
      const payload = authMode === "register"
        ? { name: authName.trim(), email: authEmail.trim(), password: authPassword }
        : { email: authEmail.trim(), password: authPassword };
      const response = await fetch(`${API}/auth/${endpoint}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        credentials: "include", body: JSON.stringify(payload)
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Could not complete the request.");
      setUser(data.user);
      setAuthMode(null); setAuthName(""); setAuthEmail(""); setAuthPassword("");
      notify(authMode === "register" ? "Welcome to Upford!" : "You are now signed in.");
    } catch (err) {
      setAuthError(err.message || "Could not connect. Check that the API server is running.");
    } finally { setAuthBusy(false); }
  }
  async function logout() {
    try { await fetch(`${API}/auth/logout`, { method: "POST", credentials: "include" }); } catch {}
    setUser(null); notify("You have signed out.");
  }
  function startQuiz() {
    setQuizIndex(0); setQuizChoice(null); setQuizScore(0); setQuizFinished(false); setQuizOpen(true);
  }
  function answerQuiz() {
    if (quizChoice === null) return;
    const score = quizScore + (quizChoice === QUIZ[quizIndex].answer ? 1 : 0);
    setQuizScore(score);
    if (quizIndex === QUIZ.length - 1) setQuizFinished(true);
    else { setQuizIndex(quizIndex + 1); setQuizChoice(null); }
  }
  function openSubject(subject) {
    setSubjectId(subject.id); setTopic(null); setPage("Subjects");
  }
  function openTopic(subject, title) {
    setSubjectId(subject.id); setTopic(title); setPage("Lesson");
  }

  return (
    <div className="app">
      <header className="topbar">
        <button className="brand" onClick={() => { setPage("Home"); setTopic(null); }} aria-label="Upford home">
          <span className="brand-icon">u<span>.</span></span><span>upford<span className="brand-period">.</span></span>
        </button>
        <nav className="main-nav" aria-label="Main navigation">
          {["Home", "Subjects", "My Learning", "About"].map(item => <button key={item} className={page === item || (item === "Subjects" && page === "Lesson") ? "nav-item active" : "nav-item"} onClick={() => { setPage(item); setTopic(null); }}>{item}</button>)}
        </nav>
        <div className="top-actions">
          {user ? <><span className="user-chip"><span className="user-avatar">{user.name.slice(0,1).toUpperCase()}</span><span className="user-name">{user.name.split(" ")[0]}</span></span><button className="button-outline small-button" onClick={logout}>Sign out</button></> :
            <><button className="login-button" onClick={() => { setAuthMode("login"); setAuthError(""); }}>Log in</button><button className="button-primary small-button" onClick={() => { setAuthMode("register"); setAuthError(""); }}>Join Upford <span>↗</span></button></>}
        </div>
      </header>

      <main>
        {page === "Home" && <HomePage user={user} onExplore={() => setPage("Subjects")} onRegister={() => { setAuthMode("register"); setAuthError(""); }} onQuiz={startQuiz} onSubject={openSubject} />}
        {page === "Subjects" && !topic && <SubjectsPage year={year} setYear={setYear} search={search} setSearch={setSearch} subjects={visibleSubjects} allSubjects={SUBJECTS} saved={saved} onSubject={openSubject} onTopic={openTopic} />}
        {page === "Subjects" && topic && <LessonPage topic={topic} subject={activeSubject} lesson={lesson} saved={saved} completed={completed} onBack={() => setTopic(null)} onSave={() => toggleSaved(topic)} onComplete={() => markCompleted(topic)} />}
        {page === "Lesson" && <LessonPage topic={topic} subject={activeSubject} lesson={lesson} saved={saved} completed={completed} onBack={() => { setPage("Subjects"); setTopic(null); }} onSave={() => toggleSaved(topic)} onComplete={() => markCompleted(topic)} />}
        {page === "My Learning" && <MyLearning saved={saved} completed={completed} onOpen={(title) => { const s = SUBJECTS.find(sub => sub.topics.includes(title)) || SUBJECTS[0]; openTopic(s, title); }} onBrowse={() => setPage("Subjects")} />}
        {page === "About" && <AboutPage onExplore={() => setPage("Subjects")} />}
      </main>

      <section className="newsletter">
        <div><div className="eyebrow light">YOUR FUTURE IS WORTH THE EFFORT</div><h2>One lesson can change everything.</h2><p>Keep showing up. Keep asking questions. Keep growing.</p></div>
        <button className="newsletter-button" onClick={() => setPage("Subjects")}>Explore learning <span>→</span></button>
        <div className="newsletter-spark">✳</div>
      </section>

      <footer className="footer">
        <button className="brand footer-brand" onClick={() => setPage("Home")}><span className="brand-icon">u<span>.</span></span><span>upford<span className="brand-period">.</span></span></button>
        <span>Learn. Practise. Grow.</span>
        <span className="footer-status"><i className={apiStatus === "online" ? "status-dot online" : "status-dot"}></i> {apiStatus === "online" ? "Learning API connected" : apiStatus === "checking" ? "Checking API…" : "Demo mode · start API for accounts"}</span>
        <span>© 2026 Upford · Made for learners in Ghana</span>
      </footer>

      {toast && <div className="toast" role="status">✓ {toast}</div>}

      {authMode && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setAuthMode(null); }}>
        <section className="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title">
          <button className="modal-close" aria-label="Close" onClick={() => setAuthMode(null)}>×</button>
          <div className="modal-brand brand-icon">u<span>.</span></div>
          <div className="eyebrow">{authMode === "register" ? "YOUR LEARNING JOURNEY" : "WELCOME BACK"}</div>
          <h2 id="auth-title">{authMode === "register" ? "Create your account." : "Log in to Upford."}</h2>
          <p className="modal-intro">{authMode === "register" ? "Join a community built around learning and growth." : "Pick up where your learning journey paused."}</p>
          <form className="auth-form" onSubmit={submitAuth}>
            {authMode === "register" && <label>Full name<input value={authName} onChange={e => setAuthName(e.target.value)} placeholder="Your full name" autoComplete="name" minLength="2" maxLength="80" required /></label>}
            <label>Email address<input type="email" value={authEmail} onChange={e => setAuthEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" maxLength="254" required /></label>
            <label>Password<input type="password" value={authPassword} onChange={e => setAuthPassword(e.target.value)} placeholder={authMode === "register" ? "At least 8 characters" : "Your password"} autoComplete={authMode === "register" ? "new-password" : "current-password"} minLength={authMode === "register" ? 8 : 1} maxLength="72" required /></label>
            {authMode === "register" && <p className="input-hint">Choose a unique password you don't use on other websites.</p>}
            {authError && <p className="form-error" role="alert">{authError}</p>}
            <button className="button-primary auth-submit" type="submit" disabled={authBusy}>{authBusy ? "Please wait…" : authMode === "register" ? "Create account →" : "Log in →"}</button>
          </form>
          <p className="switch-auth">{authMode === "register" ? "Already learning with us?" : "New to Upford?"} <button onClick={() => { setAuthMode(authMode === "register" ? "login" : "register"); setAuthError(""); }}>{authMode === "register" ? "Log in" : "Create an account"}</button></p>
          <p className="modal-footnote">Upford is a learning project. Keep your account details private.</p>
        </section>
      </div>}

      {quizOpen && <QuizModal index={quizIndex} choice={quizChoice} setChoice={setQuizChoice} score={quizScore} finished={quizFinished} onAnswer={answerQuiz} onClose={() => setQuizOpen(false)} onRestart={startQuiz} />}
    </div>
  );
}

function HomePage({ user, onExplore, onRegister, onQuiz, onSubject }) {
  return <>
    <section className="hero">
      <div className="hero-content">
        <div className="eyebrow"><span className="eyebrow-dot"></span> A BRIGHTER WAY TO LEARN</div>
        <h1>Your future<br />starts with <span>learning.</span></h1>
        <p className="hero-description">A learning space designed for Ghanaian SHS students — explore concepts, practise skills and take your next step with confidence.</p>
        <div className="hero-buttons"><button className="button-primary" onClick={onExplore}>Explore subjects <span>→</span></button>{!user && <button className="button-outline" onClick={onRegister}>Create free account</button>}</div>
        <div className="hero-foot"><div className="mini-avatars"><i>U</i><i>✦</i><i>✓</i></div><span>For curious minds with big goals.</span></div>
      </div>
      <div className="hero-visual">
        <div className="visual-halo"></div><div className="visual-orbit orbit-a"></div><div className="visual-orbit orbit-b"></div>
        <div className="dashboard-card">
          <div className="dash-top"><span className="dash-logo">u.</span><span className="dash-label">YOUR LEARNING SPACE</span><span className="dash-menu">•••</span></div>
          <div className="welcome-small">WELCOME TO YOUR NEXT CHAPTER</div><h3>Every expert<br />was once a learner.</h3>
          <div className="dash-progress-head"><span>Learning is a journey</span><b>Keep going ✦</b></div><div className="dash-progress"><span></span></div>
          <div className="dash-subjects"><button onClick={() => onSubject(SUBJECTS[0])}><i className="subject-mini violet">∑</i><span>Mathematics</span></button><button onClick={() => onSubject(SUBJECTS[1])}><i className="subject-mini peach">Aa</i><span>English</span></button><button onClick={() => onSubject(SUBJECTS[3])}><i className="subject-mini sky">&lt;/&gt;</i><span>Computing</span></button></div>
        </div>
        <div className="float-card float-top"><span className="float-icon sunshine">✦</span><div><b>Stay curious</b><small>Discover something new</small></div></div>
        <div className="float-card float-bottom"><span className="float-icon leaf">✓</span><div><b>Progress, not perfection</b><small>One step at a time</small></div></div>
        <span className="star star-one">✳</span><span className="star star-two">✦</span><span className="star star-three">✧</span>
      </div>
    </section>
    <section className="value-strip"><div><strong>SHS 1–3</strong><span>Learning for your journey</span></div><div><strong>6 subjects</strong><span>Explore different interests</span></div><div><strong>Learn + practise</strong><span>Build confidence over time</span></div></section>
    <section className="home-subjects section-wrap">
      <div className="section-title-row"><div><div className="eyebrow">YOUR LEARNING STARTS HERE</div><h2>What will you learn today?</h2><p>Choose a subject and take one small step forward.</p></div><button className="text-link" onClick={onExplore}>View all subjects ↗</button></div>
      <div className="home-subject-grid">{SUBJECTS.slice(0,4).map(s => <button className="home-subject" key={s.id} onClick={() => onSubject(s)}><span className={`subject-icon ${s.color}`}>{s.icon}</span><span className="subject-short">{s.short}</span><b>{s.name}</b><small>{s.summary}</small><span className="card-arrow">↗</span></button>)}</div>
    </section>
    <section className="practice-banner"><div className="practice-icon">✎</div><div><div className="eyebrow">A LITTLE PRACTICE GOES A LONG WAY</div><h2>Ready for a quick brain boost?</h2><p>Try a short sample quiz across Maths, English and Computing.</p></div><button className="button-primary" onClick={onQuiz}>Try the mini quiz <span>→</span></button></section>
  </>;
}

function SubjectsPage({ year, setYear, search, setSearch, subjects, allSubjects, saved, onSubject, onTopic }) {
  const [expanded, setExpanded] = useState(null);
  return <section className="content-section">
    <div className="page-heading"><div className="eyebrow">THE LEARNING CENTRE</div><h1>Make room for <span>curiosity.</span></h1><p>Explore a subject, pick a topic and learn at your own pace.</p></div>
    <div className="subject-toolbar"><label className="search-input"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search subjects…" aria-label="Search subjects" /></label><div className="year-tabs" aria-label="Choose SHS year">{["SHS 1","SHS 2","SHS 3"].map(y => <button className={year === y ? "selected" : ""} key={y} onClick={() => setYear(y)}>{y}</button>)}</div></div>
    <div className="all-subject-grid">{subjects.map(s => <article className="subject-tile" key={s.id}><button className="tile-main" onClick={() => { onSubject(s); setExpanded(expanded === s.id ? null : s.id); }}><span className={`subject-icon ${s.color}`}>{s.icon}</span><span className="tile-code">{s.short} · {year}</span><h3>{s.name}</h3><p>{s.summary}</p><span className="tile-footer">Explore topics <i>↗</i></span></button><div className="topic-chips">{s.topics.slice(0,3).map(t => <button key={t} onClick={() => onTopic(s,t)}>{t}{saved.includes(t) && <span> ✓</span>}</button>)}</div><button className="all-topics" onClick={() => setExpanded(expanded === s.id ? null : s.id)}>{expanded === s.id ? "Hide topics −" : `See all ${s.topics.length} topics +`}</button>{expanded === s.id && <div className="expanded-topics">{s.topics.map(t => <button key={t} onClick={() => onTopic(s,t)}><span>{t}</span><span>→</span></button>)}</div>}</article>)}</div>
    {subjects.length === 0 && <div className="empty-state"><span>⌕</span><h3>No subjects found</h3><p>Try another search term.</p><button className="button-outline" onClick={() => setSearch("")}>Clear search</button></div>}
    <p className="curriculum-note">These are starter topics for demonstration. Check all lesson content against the current Ghana Education Service curriculum before classroom or exam use.</p>
  </section>;
}

function LessonPage({ topic, subject, lesson, saved, completed, onBack, onSave, onComplete }) {
  return <section className="content-section lesson-page">
    <button className="back-link" onClick={onBack}>← Back to subjects</button>
    <div className="lesson-hero"><span className={`subject-icon ${subject.color}`}>{subject.icon}</span><div className="eyebrow">{subject.name.toUpperCase()} · LEARNING NOTE</div><h1>{topic}</h1><p>Clear ideas, helpful examples and a little practice to strengthen your understanding.</p><div className="lesson-actions"><button className="button-primary" onClick={onComplete}>{completed.includes(topic) ? "✓ Completed" : "Mark as complete"}</button><button className="button-outline" onClick={onSave}>{saved.includes(topic) ? "★ Saved" : "☆ Save lesson"}</button></div></div>
    <div className="lesson-layout"><article className="lesson-content"><div className="lesson-section-label">01 · UNDERSTAND</div><h2>The big idea</h2><p>{lesson.intro}</p><div className="concept-list">{lesson.points.map((p,i) => <div key={p}><span>{String(i+1).padStart(2,"0")}</span><p>{p}</p></div>)}</div><div className="example-box"><div className="example-title"><span>✦</span> WORKED EXAMPLE / STUDY TIP</div><p>{lesson.example}</p></div><div className="reflection-box"><h3>Pause and reflect</h3><p>Can you explain the main idea in your own words? Try writing a two-sentence summary before moving on.</p><button className="text-link" onClick={onComplete}>{completed.includes(topic) ? "Lesson completed ✓" : "I've finished this lesson →"}</button></div></article><aside className="lesson-aside"><div className="aside-card"><span className="aside-icon">✎</span><h3>Make it stick</h3><p>After reading, close your notes and write down three things you remember.</p></div><div className="aside-card lavender-card"><span className="aside-icon">✦</span><h3>Keep your progress</h3><p>Save this lesson to find it again in My Learning on this device.</p><button className="button-outline" onClick={onSave}>{saved.includes(topic) ? "Saved ✓" : "Save lesson"}</button></div><div className="curriculum-mini">Learning tip: consistency beats cramming. Short study sessions can help you remember more.</div></aside></div>
  </section>;
}

function MyLearning({ saved, completed, onOpen, onBrowse }) {
  return <section className="content-section"><div className="page-heading"><div className="eyebrow">YOUR PERSONAL SPACE</div><h1>Look how far <span>you've come.</span></h1><p>Your saved lessons and completed topics are kept in this browser.</p></div><div className="progress-summary"><div><span>Saved lessons</span><strong>{saved.length}</strong></div><div><span>Completed topics</span><strong>{completed.length}</strong></div><div><span>Learning habit</span><strong>{completed.length ? "Growing ✦" : "Start today"}</strong></div></div><div className="learning-columns"><div><div className="list-heading"><h2>Saved for later</h2><span>{saved.length} lessons</span></div>{saved.length ? <div className="saved-list">{saved.map(t => <button key={t} onClick={() => onOpen(t)}><span className="saved-book">▤</span><span><b>{t}</b><small>Saved lesson · Open to review</small></span><i>→</i></button>)}</div> : <div className="empty-card"><span>☆</span><h3>Your reading list starts here.</h3><p>Save a lesson you want to revisit.</p><button className="button-outline" onClick={onBrowse}>Browse subjects</button></div>}</div><div><div className="list-heading"><h2>Completed</h2><span>{completed.length} topics</span></div>{completed.length ? <div className="saved-list">{completed.map(t => <button key={t} onClick={() => onOpen(t)}><span className="done-book">✓</span><span><b>{t}</b><small>Completed · Review any time</small></span><i>↗</i></button>)}</div> : <div className="empty-card"><span>✦</span><h3>Every step counts.</h3><p>Mark a topic complete when you finish it.</p><button className="button-outline" onClick={onBrowse}>Start learning</button></div>}</div></div></section>;
}

function AboutPage({ onExplore }) {
  return <section className="content-section about-page"><div className="about-intro"><div className="eyebrow">WHY UPFORD EXISTS</div><h1>Education should <span>open doors.</span></h1><p>Upford is an educational technology project with a simple goal: help learners in Ghana understand concepts, practise with purpose and build confidence one step at a time.</p><button className="button-primary" onClick={onExplore}>Start exploring <span>→</span></button></div><div className="mission-grid"><article><span>01</span><h3>Understand</h3><p>Clear explanations that help learners build strong foundations.</p></article><article><span>02</span><h3>Practise</h3><p>Use examples, revision and questions to strengthen understanding.</p></article><article><span>03</span><h3>Grow</h3><p>Build useful habits and keep moving toward your goals.</p></article></div><p className="curriculum-note">Upford is an independent learning project and is not an official Ghana Education Service website.</p></section>;
}

function QuizModal({ index, choice, setChoice, score, finished, onAnswer, onClose, onRestart }) {
  const current = QUIZ[index];
  const [revealed, setRevealed] = useState(false);
  useEffect(() => { setRevealed(false); }, [index]);
  const isCorrect = choice === current.answer;
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className="quiz-modal" role="dialog" aria-modal="true" aria-labelledby="quiz-title"><button className="modal-close" onClick={onClose} aria-label="Close quiz">×</button>{finished ? <div className="quiz-result"><span className="result-star">✦</span><div className="eyebrow">QUIZ COMPLETE</div><h2>You showed up. That's a win.</h2><p>You scored <strong>{score} out of {QUIZ.length}</strong>. Keep practising and your confidence will grow.</p><div className="result-meter"><span style={{width:`${score/QUIZ.length*100}%`}}></span></div><button className="button-primary" onClick={onRestart}>Try again ↻</button><button className="button-outline" onClick={onClose}>Back to learning</button></div> : <><div className="eyebrow">QUICK BRAIN BOOST · {index+1} OF {QUIZ.length}</div><div className="quiz-progress">{QUIZ.map((q,i)=><span key={q.question} className={i <= index ? "filled" : ""}></span>)}</div><h2 id="quiz-title">{current.question}</h2><div className="quiz-options">{current.options.map((option,i)=><button key={option} className={`quiz-option ${revealed && i === current.answer ? "correct" : ""} ${revealed && choice === i && i !== current.answer ? "incorrect" : ""} ${choice === i ? "chosen" : ""}`} disabled={revealed} onClick={() => setChoice(i)}><span>{String.fromCharCode(65+i)}</span>{option}{revealed && i === current.answer && <b>✓</b>}</button>)}</div>{revealed && <p className={isCorrect ? "quiz-feedback good" : "quiz-feedback"}>{isCorrect ? "Correct! " : "Not quite. "}{current.explain}</p>}{!revealed ? <button className="button-primary quiz-next" disabled={choice === null} onClick={() => setRevealed(true)}>Check answer →</button> : <button className="button-primary quiz-next" onClick={onAnswer}>{index === QUIZ.length-1 ? "See result →" : "Next question →"}</button>}<p className="quiz-disclaimer">Sample practice questions, not official examination questions.</p></>}</section></div>;
}
