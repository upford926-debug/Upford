# Upford — Ghana Learning Platform

Responsive React learning website with Express + SQLite backend and student registration/login.

## Requirements
- Node.js 20 or a recent LTS release
- Internet connection for the first package install (Google Fonts are optional)

## Install
1. Extract this ZIP.
2. Open a terminal inside `upford_website`.
3. Run `npm install`.

## Start the website
Terminal 1:
```bash
npm run dev
```
Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

## Start the backend/database
Terminal 2, in the same project folder:
```bash
npm run server
```
API address: `http://localhost:3001`.

Test these endpoints in a browser:
- `http://localhost:3001/api/health`
- `http://localhost:3001/api/subjects`
- `http://localhost:3001/api/lessons`

## Try the features
- Browse six sample subjects and their topics.
- Open lesson notes, save lessons, and mark topics complete.
- Try the interactive mini quiz and see your score.
- Register, log in, refresh the page, and sign out. Registration/login needs the API server running.
- My Learning saves sample progress in this browser using localStorage; it is not yet synced to the student account or across devices.

## Student accounts and security
- SQLite stores users in `upford.db`; session records use `sessions.sqlite`.
- Passwords are hashed using bcrypt and are not stored as plaintext.
- Session cookies are HttpOnly, session IDs are regenerated after login/registration, and authentication attempts are rate-limited.
- This is a starter project, not an audited production system. Before public launch, use HTTPS, set `NODE_ENV=production`, set a strong random `SESSION_SECRET` (at least 32 characters), set `CLIENT_ORIGIN` to the actual frontend origin, configure hosting and cookie/CSRF protections, and add email verification, password reset, privacy policy, backups and a tested account-deletion flow.
- The lesson notes and questions are sample educational content. Review against current Ghana curriculum requirements before publishing as official study material.
