import express from "express";
import cors from "cors";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import session from "express-session";
import connectSqlite3 from "connect-sqlite3";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
const PORT = Number(process.env.PORT || 3001);
const production = process.env.NODE_ENV === "production";
const clientOrigin = process.env.CLIENT_ORIGIN || "http://localhost:5173";
const secret = process.env.SESSION_SECRET;

if (production && (!secret || secret.length < 32)) {
  throw new Error("Set SESSION_SECRET to a random string of at least 32 characters before production.");
}
if (!production && !secret) console.warn("Development mode: using a temporary session secret.");

app.disable("x-powered-by");
if (production) app.set("trust proxy", 1);
app.use(helmet());
app.use(cors({ origin: clientOrigin, credentials: true, methods: ["GET", "POST"], allowedHeaders: ["Content-Type"] }));
app.use(express.json({ limit: "10kb" }));

const db = new Database("upford.db");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    school_year TEXT NOT NULL,
    FOREIGN KEY(subject_id) REFERENCES subjects(id)
  );
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const initial = db.prepare("SELECT COUNT(*) AS count FROM subjects").get().count;
if (!initial) {
  const subjectInsert = db.prepare("INSERT INTO subjects (name, description) VALUES (?, ?)");
  const lessonInsert = db.prepare("INSERT INTO lessons (subject_id, title, school_year) VALUES (?, ?, ?)");
  const rows = [
    ["Core Mathematics", "Concepts, examples and practice questions.", ["Number sets", "Surds", "Sequences and series", "Algebra"]],
    ["English Language", "Grammar, comprehension and writing skills.", ["Formal letter writing", "Comprehension", "Summary writing"]],
    ["Social Studies", "Society, citizenship and development.", ["Citizenship", "The environment", "Essay practice"]],
    ["Computing", "Digital skills, programming and computer science.", ["Computer systems", "HTML and CSS", "Databases"]]
  ];
  db.transaction(() => {
    for (const [name, description, titles] of rows) {
      const id = subjectInsert.run(name, description).lastInsertRowid;
      for (const title of titles) lessonInsert.run(id, title, "SHS 1");
    }
  })();
}

const SQLiteStore = connectSqlite3(session);
app.use(session({
  name: "upford.sid",
  store: new SQLiteStore({ db: "sessions.sqlite", dir: ".", table: "sessions", concurrentDB: true }),
  secret: secret || "development-only-upford-secret-change-before-deploy",
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: { httpOnly: true, secure: production, sameSite: "lax", maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many attempts. Please wait 15 minutes before trying again." }
});
const cleanEmail = value => typeof value === "string" ? value.trim().toLowerCase() : "";
const safeUser = user => ({ id: user.id, name: user.name, email: user.email, createdAt: user.created_at });

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "Upford API" }));

app.get("/api/subjects", (_req, res) => {
  res.json(db.prepare("SELECT id, name, description FROM subjects ORDER BY id").all());
});
app.get("/api/lessons", (req, res) => {
  const filters = [], values = [];
  let sql = "SELECT lessons.id, lessons.title, lessons.school_year, subjects.name AS subject FROM lessons JOIN subjects ON subjects.id = lessons.subject_id";
  if (req.query.subject) { filters.push("subjects.name = ?"); values.push(String(req.query.subject)); }
  if (req.query.year) { filters.push("lessons.school_year = ?"); values.push(String(req.query.year)); }
  if (filters.length) sql += " WHERE " + filters.join(" AND ");
  sql += " ORDER BY subjects.name, lessons.id";
  res.json(db.prepare(sql).all(...values));
});

app.post("/api/auth/register", authLimiter, async (req, res, next) => {
  try {
    const name = typeof req.body.name === "string" ? req.body.name.trim() : "";
    const email = cleanEmail(req.body.email);
    const password = typeof req.body.password === "string" ? req.body.password : "";
    if (name.length < 2 || name.length > 80) return res.status(400).json({ error: "Enter a name between 2 and 80 characters." });
    if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
    if (password.length < 8 || Buffer.byteLength(password, "utf8") > 72) return res.status(400).json({ error: "Password must be at least 8 characters and no more than 72 UTF-8 bytes." });
    if (db.prepare("SELECT id FROM users WHERE email = ?").get(email)) return res.status(409).json({ error: "That email already has an account. Please log in." });

    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)").run(name, email, hash);
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = Number(result.lastInsertRowid);
      req.session.save(saveErr => {
        if (saveErr) return next(saveErr);
        const user = db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?").get(result.lastInsertRowid);
        res.status(201).json({ user: safeUser(user) });
      });
    });
  } catch (error) { next(error); }
});

app.post("/api/auth/login", authLimiter, async (req, res, next) => {
  try {
    const email = cleanEmail(req.body.email);
    const password = typeof req.body.password === "string" ? req.body.password : "";
    if (!email || !password || email.length > 254 || Buffer.byteLength(password, "utf8") > 72) return res.status(400).json({ error: "Enter your email and password." });
    const user = db.prepare("SELECT id, name, email, password_hash, created_at FROM users WHERE email = ?").get(email);
    const valid = user ? await bcrypt.compare(password, user.password_hash) : false;
    if (!valid) return res.status(401).json({ error: "Email or password is incorrect." });
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = user.id;
      req.session.save(saveErr => {
        if (saveErr) return next(saveErr);
        res.json({ user: safeUser(user) });
      });
    });
  } catch (error) { next(error); }
});

app.get("/api/auth/me", (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not signed in." });
  const user = db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?").get(req.session.userId);
  if (!user) return req.session.destroy(() => res.status(401).json({ error: "Session expired. Please log in again." }));
  res.json({ user: safeUser(user) });
});

app.post("/api/auth/logout", (req, res, next) => {
  if (!req.session) return res.status(204).end();
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("upford.sid", { httpOnly: true, secure: production, sameSite: "lax" });
    res.status(204).end();
  });
});

app.get("/api/account", (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  const user = db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?").get(req.session.userId);
  if (!user) return res.status(401).json({ error: "Please log in again." });
  res.json({ user: safeUser(user) });
});

app.use((err, _req, res, _next) => {
  console.error("Upford API error:", err.message);
  res.status(500).json({ error: "Something went wrong. Please try again." });
});
app.listen(PORT, () => console.log(`Upford API running at http://localhost:${PORT}`));
